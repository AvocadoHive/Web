<div class="d-slider-part about-slider-part">
    <div class="d-slider-inner">
        <div class="d-slide-text">
            <h2>About Us</h2>
            <div class="d-sub-portal"> <span>Customer collaboration</span>, <span>Collective<br />Excellence</span>, and <span>Forward Thinking</span></div>
            <ul>
                <!-- <li><span><i class="fa fa-solid fa-phone"></i></span> (302) 222-222 US</li> -->
                <li><span><i class="fa-solid fa-envelope"></i></span> info@avocadohive.com</li>
                <!-- <li><span><i class="fa-solid fa-location-dot"></i></span> 99 Wall St Suite 000, New York NY</li> -->
            </ul>
        </div>
        <div class="d-slide-image">
            <img src="/images/slider_image.png" alt="">
        </div>
    </div>
</div>