<div class="d-footer-main">
    <div class="footer-inner">
        <div class="d-feat-footer">
            <div class="fear-based">Want to know more about how it works? <span>Ask a question or Book a discovery call.</span></div>
            <?php if(ip_info("Visitor", "Country") == 'Philippines'): ?>
                <div class="d-prom-button"><a href="/career">Join our Team</a></div>
            <?php else: ?>
                <div class="d-prom-button"><a href="https://calendly.com/avocadohive/discovery-call-30minutes">Book a Call</a></div>
            <?php endif; ?>
            
        </div>
        <!-- <div class="d-footer-menu">
            <ul>
                <li>Privacy Policy</li>
                <li>Terms & Conditions</li>
                <li>Contact Us</li>
            </ul>
        </div> -->
    </div>
</div>
